import express from "express";
import Database from "better-sqlite3";
import fs from "node:fs";

const DB_PATH = "./books.db";           
const db = new Database(DB_PATH);
const app = express();
app.use(express.json());
app.use(express.static("public"));      

const schema = fs.readFileSync("./schema.sql", "utf8");
db.exec(schema);

const count = db.prepare("SELECT COUNT(*) AS c FROM books").get().c;
if (count === 0) {
  const seed = db.prepare(
    "INSERT INTO books (title, author, price, description, cover_url, stock) VALUES (?,?,?,?,?,?)"
  );
  [
    ["Clean Code", "Robert C. Martin", 29.99, "A Handbook of Agile Software Craftsmanship", "", 5],
    ["Deep Work", "Cal Newport", 19.99, "Rules for Focused Success", "", 8],
    ["Pragmatic Programmer", "Andrew Hunt", 24.99, "Journey to Mastery", "", 3],
  ].forEach(b => seed.run(...b));
}

const bookListQuery = db.prepare(`
  SELECT b.*,
         COALESCE(a.avg_rating, 0) AS avg_rating,
         COALESCE(a.ratings_count, 0) AS ratings_count
  FROM books b
  LEFT JOIN book_rating_agg a ON a.id = b.id
  WHERE (:q IS NULL OR b.title LIKE :like OR b.author LIKE :like)
  ORDER BY b.title
`);

const bookById = db.prepare(`
  SELECT b.*,
         COALESCE(a.avg_rating, 0) AS avg_rating,
         COALESCE(a.ratings_count, 0) AS ratings_count
  FROM books b
  LEFT JOIN book_rating_agg a ON a.id = b.id
  WHERE b.id = ?
`);

const insertRating = db.prepare(`
  INSERT OR IGNORE INTO ratings (book_id, stars, user_key) VALUES (?, ?, ?)
`);

const bookRatings = db.prepare(`
  SELECT stars, created_at FROM ratings WHERE book_id = ? ORDER BY created_at DESC LIMIT 50
`);

app.get("/api/books", (req, res) => {
  const q = req.query.q?.trim() || null;
  const like = q ? `%${q}%` : null;
  const rows = bookListQuery.all({ q, like });
  res.json(rows);
});

app.get("/api/books/:id", (req, res) => {
  const row = bookById.get(req.params.id);
  if (!row) return res.status(404).json({ error: "Not found" });
  res.json(row);
});

app.get("/api/books/:id/ratings", (req, res) => {
  res.json(bookRatings.all(req.params.id));
});

app.post("/api/books/:id/rate", (req, res) => {
  const id = Number(req.params.id);
  const stars = Number(req.body.stars);
  if (!Number.isInteger(stars) || stars < 1 || stars > 5) {
    return res.status(400).json({ error: "stars must be 1..5" });
  }
  const userKey = (req.header("x-user-key") || "").slice(0, 128) || null;
  const info = insertRating.run(id, stars, userKey);
  res.json({ ok: true, accepted: info.changes === 1 });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`StarReads running at http://localhost:${PORT}`));
