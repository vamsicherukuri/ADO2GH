PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS books (
  id INTEGER PRIMARY KEY,
  title TEXT NOT NULL,
  author TEXT NOT NULL,
  price REAL NOT NULL,
  description TEXT,
  cover_url TEXT,
  stock INTEGER DEFAULT 0
);

CREATE TABLE IF NOT EXISTS ratings (
  id INTEGER PRIMARY KEY,
  book_id INTEGER NOT NULL REFERENCES books(id) ON DELETE CASCADE,
  stars INTEGER NOT NULL CHECK (stars BETWEEN 1 AND 5),
  user_key TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  UNIQUE(book_id, user_key) ON CONFLICT IGNORE
);

CREATE VIEW IF NOT EXISTS book_rating_agg AS
SELECT
  b.id,
  ROUND(AVG(r.stars), 1) AS avg_rating,
  COUNT(r.id) AS ratings_count
FROM books b
LEFT JOIN ratings r ON r.book_id = b.id
GROUP BY b.id;
